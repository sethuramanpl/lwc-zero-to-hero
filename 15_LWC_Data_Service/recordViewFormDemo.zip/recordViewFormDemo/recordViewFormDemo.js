import { LightningElement } from 'lwc';

export default class RecordViewFormDemo extends LightningElement {}