import { LightningElement } from 'lwc';

export default class CssChildDemo extends LightningElement {}