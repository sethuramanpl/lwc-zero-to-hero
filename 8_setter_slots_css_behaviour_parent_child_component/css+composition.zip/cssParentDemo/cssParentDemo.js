import { LightningElement } from 'lwc';

export default class CssParentDemo extends LightningElement {}