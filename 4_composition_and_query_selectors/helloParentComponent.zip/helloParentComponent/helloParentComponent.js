import { LightningElement } from 'lwc';

export default class HelloParentComponent extends LightningElement {}