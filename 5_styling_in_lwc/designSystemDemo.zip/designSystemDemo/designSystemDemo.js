import { LightningElement } from 'lwc';

export default class DesignSystemDemo extends LightningElement {}