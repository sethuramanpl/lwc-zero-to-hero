import { LightningElement } from 'lwc';

export default class StylingTwo extends LightningElement {}