import { LightningElement } from 'lwc';

export default class StylingOne extends LightningElement {}