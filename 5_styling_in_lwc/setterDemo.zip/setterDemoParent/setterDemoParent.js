import { LightningElement } from 'lwc';

export default class SetterDemoParent extends LightningElement {
    userDetails = {
        name:"salesforcetroop",
        age:25
    }
}