import { LightningElement } from 'lwc';

export default class DesignToken extends LightningElement {}