import { LightningElement } from 'lwc';

export default class ReusableComponentDemo extends LightningElement {}