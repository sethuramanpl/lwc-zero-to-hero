import LightningElementWithBootstrap from '../../lib/lightningElementWithBootstrap'


export default class Navbar extends LightningElementWithBootstrap {}
