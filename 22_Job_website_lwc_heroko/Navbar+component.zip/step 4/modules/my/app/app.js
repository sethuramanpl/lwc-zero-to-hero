import LightningElementWithBootstrap from '../../lib/lightningElementWithBootstrap'

export default class App extends LightningElementWithBootstrap {}
