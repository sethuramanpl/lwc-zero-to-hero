import { LightningElement } from 'lwc';

export default class LwcUtilityBar extends LightningElement {
    fieldList = ['Name', 'Phone']
}