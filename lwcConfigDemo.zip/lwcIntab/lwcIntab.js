import { LightningElement } from 'lwc';

export default class LwcIntab extends LightningElement {}