import { LightningElement } from 'lwc';
import TYPESCRIPT_FILE from '@salesforce/contentAssetUrl/typescripthandbookbetapdf'
export default class ContentAssetFiles extends LightningElement {
    file = TYPESCRIPT_FILE
}