declare module "@salesforce/apex/CarController.getCars" {
  export default function getCars(param: {filters: any}): Promise<any>;
}
