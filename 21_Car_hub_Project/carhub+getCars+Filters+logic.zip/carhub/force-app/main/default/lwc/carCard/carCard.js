import { LightningElement } from 'lwc';

export default class CarCard extends LightningElement {}