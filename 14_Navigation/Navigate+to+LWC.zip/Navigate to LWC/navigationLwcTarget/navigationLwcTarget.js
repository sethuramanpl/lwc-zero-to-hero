import { LightningElement, api } from 'lwc';

export default class NavigationLwcTarget extends LightningElement {
    @api recordId
}